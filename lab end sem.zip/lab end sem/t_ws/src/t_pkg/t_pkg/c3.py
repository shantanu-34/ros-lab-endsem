
#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
import math
from std_srvs.srv import Empty
from turtlesim.srv import Spawn
class TurtleControllerNode(Node):
    def __init__(self):
        super().__init__("turtle_controller")
        
        self.counter=0
        self.i=0
        self.pose_ = None
        self.initial_pose =None
        self.is_moving = True
        self.left_initial_position = False
        self.cmd_vel_publisher_ = self.create_publisher(Twist, "turtle1/cmd_vel", 10)
        self.pose_subscriber_ = self.create_subscription(Pose, "turtle1/pose",self.callback_turtle_pose, 10)
        self.control_loop_timer_ = self.create_timer(0.01, self.control_loop)
            
    def callback_turtle_pose(self,msg):
        self.pose_ = msg
        if self.initial_pose is None:  
                self.initial_pose = msg
                
                self.get_logger().info(f'Initial pose: x = {self.initial_pose.x}, y = {self.initial_pose.y}')
               
       
    def stop_turtle(self):
        self.is_moving = False
        cmd_vel_msg = Twist()
        self.cmd_vel_publisher_.publish(cmd_vel_msg)
        self.get_logger().info('Turtle stopped at initial position')
    def spawn_second_turtle(self):
        # Check if we have the pose of the first turtle and it has moved
        if self.initial_pose is not None:
            x = self.initial_pose.x
            y = self.initial_pose.y
            theta = self.initial_pose.theta

            # Specify the new turtle's name
            new_turtle_name = 'turtle2'
            

            # Create a service client for the "spawn" service
            spawn_client = self.create_client(Spawn, 'spawn')
            while not spawn_client.wait_for_service(timeout_sec=1.0):
                self.get_logger().info('Service not available, waiting...')
            request = Spawn.Request()
            request.x = x
            request.y = y
            request.theta = theta
            request.name = new_turtle_name
            
            future = spawn_client.call_async(request)
            while (self.i==1):
                msg = Twist()
                msg.linear.x = 1.5
                msg.angular.z = -1.0
                self.cmd_vel_publisher_.publish(msg)
                #rclpy.spin_until_future_complete(self, future)
            
            # if future.result() is not None:
            #     self.get_logger().info(f'Spawned {new_turtle_name} successfully')
            # else:
            #     self.get_logger().error('Failed to spawn the second turtle')
            

    def control_loop(self):
        if self.pose_ == None:
            return
        tolerance = 0.01
        dist_from_initial = math.sqrt((self.pose_.x - self.initial_pose.x)**2 + (self.pose_.y - self.initial_pose.y)**2)

        if not self.left_initial_position and dist_from_initial > tolerance:
            self.left_initial_position = True

      
        if self.left_initial_position and dist_from_initial < tolerance:
            self.stop_turtle()
            self.i=1
            # msg = Twist()
            self.spawn_second_turtle()
            # self.cmd_vel_publisher_.publish(msg)
            # self.get_logger().info('Turtle reached the initial position, stopping.')
            #self.i=1
            
        else:
            msg = Twist()
            msg.linear.x = 1.0
            msg.angular.z = 1.0
            self.cmd_vel_publisher_.publish(msg)
            #distance = math.sqrt((self.pose_.x - self.initial_pose.x)**2 + (self.pose_.y - self.initial_pose.y)**2)
        
              
        
        
        
            

def main(args=None):
    rclpy.init(args=args)
    node = TurtleControllerNode()
    rclpy.spin(node)
    rclpy.shutdown()
    exit()

if __name__ == "__main__":
    main()