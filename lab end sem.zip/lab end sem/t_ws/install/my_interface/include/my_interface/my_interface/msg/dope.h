// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_interface:msg/Dope.idl
// generated code does not contain a copyright notice

#ifndef MY_INTERFACE__MSG__DOPE_H_
#define MY_INTERFACE__MSG__DOPE_H_

#include "my_interface/msg/detail/dope__struct.h"
#include "my_interface/msg/detail/dope__functions.h"
#include "my_interface/msg/detail/dope__type_support.h"

#endif  // MY_INTERFACE__MSG__DOPE_H_
