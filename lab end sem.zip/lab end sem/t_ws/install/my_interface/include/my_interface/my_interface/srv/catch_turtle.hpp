// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_INTERFACE__SRV__CATCH_TURTLE_HPP_
#define MY_INTERFACE__SRV__CATCH_TURTLE_HPP_

#include "my_interface/srv/detail/catch_turtle__struct.hpp"
#include "my_interface/srv/detail/catch_turtle__builder.hpp"
#include "my_interface/srv/detail/catch_turtle__traits.hpp"

#endif  // MY_INTERFACE__SRV__CATCH_TURTLE_HPP_
