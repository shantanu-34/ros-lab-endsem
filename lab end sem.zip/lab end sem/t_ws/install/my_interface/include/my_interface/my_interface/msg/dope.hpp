// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_INTERFACE__MSG__DOPE_HPP_
#define MY_INTERFACE__MSG__DOPE_HPP_

#include "my_interface/msg/detail/dope__struct.hpp"
#include "my_interface/msg/detail/dope__builder.hpp"
#include "my_interface/msg/detail/dope__traits.hpp"

#endif  // MY_INTERFACE__MSG__DOPE_HPP_
