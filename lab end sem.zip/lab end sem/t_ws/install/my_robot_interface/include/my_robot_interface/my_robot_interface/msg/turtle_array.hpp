// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACE__MSG__TURTLE_ARRAY_HPP_
#define MY_ROBOT_INTERFACE__MSG__TURTLE_ARRAY_HPP_

#include "my_robot_interface/msg/detail/turtle_array__struct.hpp"
#include "my_robot_interface/msg/detail/turtle_array__builder.hpp"
#include "my_robot_interface/msg/detail/turtle_array__traits.hpp"

#endif  // MY_ROBOT_INTERFACE__MSG__TURTLE_ARRAY_HPP_
