// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_robot_interface:msg/Turtle.idl
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACE__MSG__TURTLE_H_
#define MY_ROBOT_INTERFACE__MSG__TURTLE_H_

#include "my_robot_interface/msg/detail/turtle__struct.h"
#include "my_robot_interface/msg/detail/turtle__functions.h"
#include "my_robot_interface/msg/detail/turtle__type_support.h"

#endif  // MY_ROBOT_INTERFACE__MSG__TURTLE_H_
