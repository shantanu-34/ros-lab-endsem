#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
     
     
class obstacle(Node):
    def __init__(self):
        super().__init__("move_r")
        self.target_x = 2
        self.target_y = 2
        self.publisher = self.create_publisher(Twist, "cmd_vel", 10)
        self.subscriber=self.create_subscription(LaserScan,"gazebo_lidar/out",self.value_loop,12)
               
    def value_loop(self, msg):
        
       
        vel=Twist()
        
        for i in range(158,221):
            print(msg.ranges[i])
        
        if (str(msg.ranges[158]) == 'inf'):
            vel.linear.x = 0.0
            vel.angular.z = 0.4*round(2) 
             
           
        self.publisher.publish(vel)
        
     
def main(args=None):
    rclpy.init(args=args)
    node = obstacle()
    rclpy.spin(node)
    rclpy.shutdown()
    
       
if __name__ == "__main__":
	main()