# import os
# from launch import LaunchDescription
# from launch_ros.actions import Node
# from launch.actions import  ExecuteProcess
# from launch_ros.substitutions import FindPackageShare
# from launch.substitutions import Command
# import xacro
# package_name = 'lab6'
# robot_name_in_model = 'ur5'
# def generate_launch_description():
   
#     urdf = '/home/shantanu/ur_ws/src/lab6/urdf/uu.urdf'
#     robot_description = {"robot_description": urdf} 

#     spawn_x_val = '0.0'
#     spawn_y_val = '0.0'
#     spawn_z_val = '0.0'
#     spawn_yaw_val = '0.00'
  
    
    
#     return LaunchDescription([
        
        

#         Node(
#             package='robot_state_publisher',
#             executable='robot_state_publisher',
#             name='robot_state_publisher',
#             #parameters=[{'robot_description': Command(['xacro', urdf])}],
#             output='screen',
#             arguments=[urdf]),
#         Node(
#             package='joint_state_publisher',
#             executable='joint_state_publisher',
#             name='joint_state_publisher',
#             arguments=[urdf]),
        
# #  Gazebo related stuff required to launch the robot in simulation
#         ExecuteProcess(
#             cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so'],
#             output='screen'),
#         Node(
#             name='urdf_spawner',
#             package='gazebo_ros',
#             executable='spawn_entity.py'),
#         Node(package='gazebo_ros', executable='spawn_entity.py',
#                 arguments=["-entity","lab6","-b","-file", urdf],
#                 output='screen',
        
#             # arguments=['-entity', robot_name_in_model, 
#             #     '-topic', 'robot_description',
#             #         '-x', spawn_x_val,
#             #         '-y', spawn_y_val,
#             #         '-z', spawn_z_val,
#             #         '-Y', spawn_yaw_val],
#             # output='screen')
#             )
        
            
#   ])
    
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import  ExecuteProcess
def generate_launch_description():
    #urdf = '/home/shantanu/g_ws/src/lab/urdf/three_wheeled_robot.urdf'
    #urdf = '/home/shantanu/g_ws/src/lab/urdf/lab4.urdf'
    urdf = '/home/shantanu/ur_ws/src/lab6/urdf/uu.urdf'
    return LaunchDescription([

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            arguments=[urdf]),
        Node(
            package='joint_state_publisher',
            executable='joint_state_publisher',
            name='joint_state_publisher',
            arguments=[urdf]),
#  Gazebo related stuff required to launch the robot in simulation
        ExecuteProcess(
            cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so'],
            output='screen'),
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            name='urdf_spawner',
            output='screen',
            arguments=["-topic", "/robot_description", "-entity", "lab6"])
  ])