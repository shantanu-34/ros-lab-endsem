// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from my_robot_interface:msg/ManufactureDate.idl
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACE__MSG__DETAIL__MANUFACTURE_DATE__BUILDER_HPP_
#define MY_ROBOT_INTERFACE__MSG__DETAIL__MANUFACTURE_DATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "my_robot_interface/msg/detail/manufacture_date__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace my_robot_interface
{

namespace msg
{

namespace builder
{

class Init_ManufactureDate_year
{
public:
  explicit Init_ManufactureDate_year(::my_robot_interface::msg::ManufactureDate & msg)
  : msg_(msg)
  {}
  ::my_robot_interface::msg::ManufactureDate year(::my_robot_interface::msg::ManufactureDate::_year_type arg)
  {
    msg_.year = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_robot_interface::msg::ManufactureDate msg_;
};

class Init_ManufactureDate_month
{
public:
  explicit Init_ManufactureDate_month(::my_robot_interface::msg::ManufactureDate & msg)
  : msg_(msg)
  {}
  Init_ManufactureDate_year month(::my_robot_interface::msg::ManufactureDate::_month_type arg)
  {
    msg_.month = std::move(arg);
    return Init_ManufactureDate_year(msg_);
  }

private:
  ::my_robot_interface::msg::ManufactureDate msg_;
};

class Init_ManufactureDate_date
{
public:
  Init_ManufactureDate_date()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ManufactureDate_month date(::my_robot_interface::msg::ManufactureDate::_date_type arg)
  {
    msg_.date = std::move(arg);
    return Init_ManufactureDate_month(msg_);
  }

private:
  ::my_robot_interface::msg::ManufactureDate msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_robot_interface::msg::ManufactureDate>()
{
  return my_robot_interface::msg::builder::Init_ManufactureDate_date();
}

}  // namespace my_robot_interface

#endif  // MY_ROBOT_INTERFACE__MSG__DETAIL__MANUFACTURE_DATE__BUILDER_HPP_
