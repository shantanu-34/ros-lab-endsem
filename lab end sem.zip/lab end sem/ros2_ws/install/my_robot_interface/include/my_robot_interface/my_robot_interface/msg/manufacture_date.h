// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_robot_interface:msg/ManufactureDate.idl
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACE__MSG__MANUFACTURE_DATE_H_
#define MY_ROBOT_INTERFACE__MSG__MANUFACTURE_DATE_H_

#include "my_robot_interface/msg/detail/manufacture_date__struct.h"
#include "my_robot_interface/msg/detail/manufacture_date__functions.h"
#include "my_robot_interface/msg/detail/manufacture_date__type_support.h"

#endif  // MY_ROBOT_INTERFACE__MSG__MANUFACTURE_DATE_H_
