// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACE__MSG__MANUFACTURE_DATE_HPP_
#define MY_ROBOT_INTERFACE__MSG__MANUFACTURE_DATE_HPP_

#include "my_robot_interface/msg/detail/manufacture_date__struct.hpp"
#include "my_robot_interface/msg/detail/manufacture_date__builder.hpp"
#include "my_robot_interface/msg/detail/manufacture_date__traits.hpp"

#endif  // MY_ROBOT_INTERFACE__MSG__MANUFACTURE_DATE_HPP_
