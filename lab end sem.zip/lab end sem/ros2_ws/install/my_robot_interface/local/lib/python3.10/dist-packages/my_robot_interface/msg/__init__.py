from my_robot_interface.msg._manufacture_date import ManufactureDate  # noqa: F401
