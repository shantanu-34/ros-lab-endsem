import rclpy
import launch
from launch import LaunchDescription
from launch_ros.actions import Node
 
def generate_launch_description():
    return LaunchDescription([
        Node(
            package='my_py_pkg',
            namespace='ns1',
            executable='first_publisher',
            name='first_publisher',
            arguments=['--ros-args', '--log-level', 'fatal'],
        ),
        Node(
            package='my_py_pkg',
            name='first_suscriber',
            namespace='ns1',
            executable='first_suscriber',
            arguments=['--ros-args', '--log-level', 'fatal'],
        )
    ])