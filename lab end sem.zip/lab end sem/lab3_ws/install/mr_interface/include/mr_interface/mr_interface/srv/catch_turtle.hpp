// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MR_INTERFACE__SRV__CATCH_TURTLE_HPP_
#define MR_INTERFACE__SRV__CATCH_TURTLE_HPP_

#include "mr_interface/srv/detail/catch_turtle__struct.hpp"
#include "mr_interface/srv/detail/catch_turtle__builder.hpp"
#include "mr_interface/srv/detail/catch_turtle__traits.hpp"

#endif  // MR_INTERFACE__SRV__CATCH_TURTLE_HPP_
