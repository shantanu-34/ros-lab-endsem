// generated from rosidl_generator_c/resource/idl.h.em
// with input from mr_interface:srv/CatchTurtle.idl
// generated code does not contain a copyright notice

#ifndef MR_INTERFACE__SRV__CATCH_TURTLE_H_
#define MR_INTERFACE__SRV__CATCH_TURTLE_H_

#include "mr_interface/srv/detail/catch_turtle__struct.h"
#include "mr_interface/srv/detail/catch_turtle__functions.h"
#include "mr_interface/srv/detail/catch_turtle__type_support.h"

#endif  // MR_INTERFACE__SRV__CATCH_TURTLE_H_
