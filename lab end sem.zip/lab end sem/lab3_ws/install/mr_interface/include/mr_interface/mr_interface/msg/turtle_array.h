// generated from rosidl_generator_c/resource/idl.h.em
// with input from mr_interface:msg/TurtleArray.idl
// generated code does not contain a copyright notice

#ifndef MR_INTERFACE__MSG__TURTLE_ARRAY_H_
#define MR_INTERFACE__MSG__TURTLE_ARRAY_H_

#include "mr_interface/msg/detail/turtle_array__struct.h"
#include "mr_interface/msg/detail/turtle_array__functions.h"
#include "mr_interface/msg/detail/turtle_array__type_support.h"

#endif  // MR_INTERFACE__MSG__TURTLE_ARRAY_H_
