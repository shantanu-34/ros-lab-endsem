// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from mr_interface:msg/Turtle.idl
// generated code does not contain a copyright notice

#ifndef MR_INTERFACE__MSG__DETAIL__TURTLE__BUILDER_HPP_
#define MR_INTERFACE__MSG__DETAIL__TURTLE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "mr_interface/msg/detail/turtle__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace mr_interface
{

namespace msg
{

namespace builder
{

class Init_Turtle_theta
{
public:
  explicit Init_Turtle_theta(::mr_interface::msg::Turtle & msg)
  : msg_(msg)
  {}
  ::mr_interface::msg::Turtle theta(::mr_interface::msg::Turtle::_theta_type arg)
  {
    msg_.theta = std::move(arg);
    return std::move(msg_);
  }

private:
  ::mr_interface::msg::Turtle msg_;
};

class Init_Turtle_y
{
public:
  explicit Init_Turtle_y(::mr_interface::msg::Turtle & msg)
  : msg_(msg)
  {}
  Init_Turtle_theta y(::mr_interface::msg::Turtle::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_Turtle_theta(msg_);
  }

private:
  ::mr_interface::msg::Turtle msg_;
};

class Init_Turtle_x
{
public:
  explicit Init_Turtle_x(::mr_interface::msg::Turtle & msg)
  : msg_(msg)
  {}
  Init_Turtle_y x(::mr_interface::msg::Turtle::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_Turtle_y(msg_);
  }

private:
  ::mr_interface::msg::Turtle msg_;
};

class Init_Turtle_name
{
public:
  Init_Turtle_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Turtle_x name(::mr_interface::msg::Turtle::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_Turtle_x(msg_);
  }

private:
  ::mr_interface::msg::Turtle msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::mr_interface::msg::Turtle>()
{
  return mr_interface::msg::builder::Init_Turtle_name();
}

}  // namespace mr_interface

#endif  // MR_INTERFACE__MSG__DETAIL__TURTLE__BUILDER_HPP_
