// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MR_INTERFACE__MSG__TURTLE_ARRAY_HPP_
#define MR_INTERFACE__MSG__TURTLE_ARRAY_HPP_

#include "mr_interface/msg/detail/turtle_array__struct.hpp"
#include "mr_interface/msg/detail/turtle_array__builder.hpp"
#include "mr_interface/msg/detail/turtle_array__traits.hpp"

#endif  // MR_INTERFACE__MSG__TURTLE_ARRAY_HPP_
