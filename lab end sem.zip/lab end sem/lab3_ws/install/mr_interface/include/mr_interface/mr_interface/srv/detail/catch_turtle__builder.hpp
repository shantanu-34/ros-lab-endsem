// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from mr_interface:srv/CatchTurtle.idl
// generated code does not contain a copyright notice

#ifndef MR_INTERFACE__SRV__DETAIL__CATCH_TURTLE__BUILDER_HPP_
#define MR_INTERFACE__SRV__DETAIL__CATCH_TURTLE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "mr_interface/srv/detail/catch_turtle__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace mr_interface
{

namespace srv
{

namespace builder
{

class Init_CatchTurtle_Request_name
{
public:
  Init_CatchTurtle_Request_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::mr_interface::srv::CatchTurtle_Request name(::mr_interface::srv::CatchTurtle_Request::_name_type arg)
  {
    msg_.name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::mr_interface::srv::CatchTurtle_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::mr_interface::srv::CatchTurtle_Request>()
{
  return mr_interface::srv::builder::Init_CatchTurtle_Request_name();
}

}  // namespace mr_interface


namespace mr_interface
{

namespace srv
{

namespace builder
{

class Init_CatchTurtle_Response_success
{
public:
  Init_CatchTurtle_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::mr_interface::srv::CatchTurtle_Response success(::mr_interface::srv::CatchTurtle_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::mr_interface::srv::CatchTurtle_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::mr_interface::srv::CatchTurtle_Response>()
{
  return mr_interface::srv::builder::Init_CatchTurtle_Response_success();
}

}  // namespace mr_interface

#endif  // MR_INTERFACE__SRV__DETAIL__CATCH_TURTLE__BUILDER_HPP_
