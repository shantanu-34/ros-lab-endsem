// generated from rosidl_generator_c/resource/idl.h.em
// with input from mr_interface:msg/Turtle.idl
// generated code does not contain a copyright notice

#ifndef MR_INTERFACE__MSG__TURTLE_H_
#define MR_INTERFACE__MSG__TURTLE_H_

#include "mr_interface/msg/detail/turtle__struct.h"
#include "mr_interface/msg/detail/turtle__functions.h"
#include "mr_interface/msg/detail/turtle__type_support.h"

#endif  // MR_INTERFACE__MSG__TURTLE_H_
