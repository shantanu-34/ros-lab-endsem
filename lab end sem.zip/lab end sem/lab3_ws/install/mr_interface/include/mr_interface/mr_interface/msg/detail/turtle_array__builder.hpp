// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from mr_interface:msg/TurtleArray.idl
// generated code does not contain a copyright notice

#ifndef MR_INTERFACE__MSG__DETAIL__TURTLE_ARRAY__BUILDER_HPP_
#define MR_INTERFACE__MSG__DETAIL__TURTLE_ARRAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "mr_interface/msg/detail/turtle_array__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace mr_interface
{

namespace msg
{

namespace builder
{

class Init_TurtleArray_turtles
{
public:
  Init_TurtleArray_turtles()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::mr_interface::msg::TurtleArray turtles(::mr_interface::msg::TurtleArray::_turtles_type arg)
  {
    msg_.turtles = std::move(arg);
    return std::move(msg_);
  }

private:
  ::mr_interface::msg::TurtleArray msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::mr_interface::msg::TurtleArray>()
{
  return mr_interface::msg::builder::Init_TurtleArray_turtles();
}

}  // namespace mr_interface

#endif  // MR_INTERFACE__MSG__DETAIL__TURTLE_ARRAY__BUILDER_HPP_
